package com.example.ppm

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import android.widget.Button
import com.example.ppm.Fragments.AboutUsFragment
import com.google.android.material.textfield.TextInputEditText
import com.parse.ParseObject
import com.parse.ParseQuery
import org.jetbrains.anko.find
import org.jetbrains.anko.startActivity

class MainActivity : AppCompatActivity() {

    private lateinit var bLogup: Button
    private lateinit var bLogin: Button
    private lateinit var txtUser: TextInputEditText
    private lateinit var txtPass: TextInputEditText


    fun Context.toast(message: CharSequence) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()

        txtUser = find(R.id.activity_main_tf_username_tx)
        txtPass = find(R.id.activity_main_tf_password_tx)


        //Boton logup
        bLogup = find(R.id.activity_main_btn_logup)
        bLogup.setOnClickListener {
            startActivity<ActivityLogup>()
        }

        //Boton login
        bLogin = find(R.id.activity_main__btn_login)
        val sharedPref = getSharedPreferences("session",Context.MODE_PRIVATE)
        bLogin.setOnClickListener{


            Log.d("brn","login works")
            //startActivity<GroupsActivity>()

            val query = ParseQuery.getQuery<ParseObject>("UserPPM")
            query.findInBackground{objects, e ->
                if (e == null) {
                    for (armor in objects) {
                        //Log.d("Parse:", "User: " + armor.get("username") + " Pass: " + armor.get("password"))
                        //Log.d("Datos:", "User: " + txtUser.text.toString() + " Pass: " + txtPass.text.toString())
                        if (armor.get("username") == txtUser.text.toString() && armor.get("password") == txtPass.text.toString()) {
                           // Log.d("Jala", "Jala")
                            val editor = sharedPref.edit()
                            editor.putString("user", armor.get("username").toString())
                            editor.apply()
                            startActivity<GroupsActivity>()
                        } else {
                            Log.d("No jala", "no jala")
                        }
                    }
                } else {
                    Log.d("Errorsazo", "Error: " + e!!.message)
                }
            }
        }
      
        // Initialize a new instance of
        val builder = AlertDialog.Builder(this@MainActivity)

        // Set the alert dialog title
        builder.setTitle(R.string.caution)

        // Display a message on alert dialog
        builder.setMessage(R.string.disclaimer)

        // Set a positive button and its click listener on alert dialog
        builder.setPositiveButton(R.string.continue_str){dialog, which ->

        }


        // Display a negative button on alert dialog
        builder.setNegativeButton(R.string.exit){dialog,which ->
            //Toast.makeText(applicationContext,"You are not agree.",Toast.LENGTH_SHORT).show()
            System.exit(0)
        }


        // Finally, make the alert dialog using builder
        val dialog: AlertDialog = builder.create()

        // Display the alert dialog on app interface
        dialog.show()
    }

    fun showAboutUs(view: View){
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.frame_main, AboutUsFragment())
            .commit()
    }
}
